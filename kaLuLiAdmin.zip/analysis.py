#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json, helper

def main():
    jsonStr = helper.readFile('data.json')
    dataArr = json.loads(jsonStr)
    print('共有数据%d条' % len(dataArr))
    # 先找出2017年以前成功下单的uid
    buySuccessBefore2017 = []
    # 状态数组
    statusArr = []
    for data in dataArr:
        if not data.get('date').startswith('2017'):
            if data.get('status') != '待付款' and data.get('status') != '订单取消':
                if not data.get('uid') in buySuccessBefore2017:
                    buySuccessBefore2017.append(data.get('uid'))

        if not data.get('status') in statusArr:
            statusArr.append(data.get('status'))
    print('订单共有%d种状态：' % len(statusArr))
    for status in statusArr:
        print(status)

    print('2017年以前共有%d人成功下单' % len(buySuccessBefore2017))
    # 1月份首次下单的人
    buySuccessInMonth1 = []
    for data in dataArr:
        if data.get('date').startswith('2017-01'):
            if data.get('status') != '待付款' and data.get('status') != '订单取消':
                uid = data.get('uid')
                if uid not in buySuccessBefore2017:
                    if uid not in buySuccessInMonth1:
                        buySuccessInMonth1.append(uid)
    print('217年1月份首次下单成功的人有%d个' % len(buySuccessInMonth1))
    # 2月份首次下单的人
    buySuccessInMonth2 = []
    for data in dataArr:
        if data.get('date').startswith('2017-02'):
            if data.get('status') != '待付款' and data.get('status') != '订单取消':
                uid = data.get('uid')
                if uid not in buySuccessBefore2017:
                    if uid not in buySuccessInMonth1:
                        if uid not in buySuccessInMonth2:
                            buySuccessInMonth2.append(uid)
    print('217年2月份首次下单成功的人有%d个' % len(buySuccessInMonth2))

    # 3月份首次下单的人
    buySuccessInMonth3 = []
    for data in dataArr:
        if data.get('date').startswith('2017-03'):
            if data.get('status') != '待付款' and data.get('status') != '订单取消':
                uid = data.get('uid')
                if uid not in buySuccessBefore2017:
                    if uid not in buySuccessInMonth1:
                        if uid not in buySuccessInMonth2:
                            if uid not in buySuccessInMonth3:
                                buySuccessInMonth3.append(uid)
    print('217年3月份首次下单成功的人有%d个' % len(buySuccessInMonth3))

    # 4月份首次下单的人
    buySuccessInMonth4 = []
    for data in dataArr:
        if data.get('date').startswith('2017-04'):
            if data.get('status') != '待付款' and data.get('status') != '订单取消':
                uid = data.get('uid')
                if uid not in buySuccessBefore2017:
                    if uid not in buySuccessInMonth1:
                        if uid not in buySuccessInMonth2:
                            if uid not in buySuccessInMonth3:
                                if uid not in buySuccessInMonth4:
                                    buySuccessInMonth4.append(uid)
    print('217年4月份首次下单成功的人有%d个' % len(buySuccessInMonth4))

    # 5月份首次下单的人
    buySuccessInMonth5 = []
    for data in dataArr:
        if data.get('date').startswith('2017-05'):
            if data.get('status') != '待付款' and data.get('status') != '订单取消':
                uid = data.get('uid')
                if uid not in buySuccessBefore2017:
                    if uid not in buySuccessInMonth1:
                        if uid not in buySuccessInMonth2:
                                if uid not in buySuccessInMonth3:
                                    if uid not in buySuccessInMonth4:
                                        if uid not in buySuccessInMonth5:
                                            buySuccessInMonth5.append(uid)
    print('217年5月份首次下单成功的人有%d个' % len(buySuccessInMonth5))

    # 6月份首次下单的人
    buySuccessInMonth6 = []
    for data in dataArr:
        if data.get('date').startswith('2017-06'):
            if data.get('status') != '待付款' and data.get('status') != '订单取消':
                uid = data.get('uid')
                if uid not in buySuccessBefore2017:
                    if uid not in buySuccessInMonth1:
                        if uid not in buySuccessInMonth2:
                            if uid not in buySuccessInMonth3:
                                if uid not in buySuccessInMonth4:
                                    if uid not in buySuccessInMonth5:
                                        if uid not in buySuccessInMonth6:
                                            buySuccessInMonth6.append(uid)
    print('217年6月份首次下单成功的人有%d个' % len(buySuccessInMonth6))

    # 7月份首次下单的人
    buySuccessInMonth7 = []
    for data in dataArr:
        if data.get('date').startswith('2017-07'):
            if data.get('status') != '待付款' and data.get('status') != '订单取消':
                uid = data.get('uid')
                if uid not in buySuccessBefore2017:
                    if uid not in buySuccessInMonth1:
                        if uid not in buySuccessInMonth2:
                            if uid not in buySuccessInMonth3:
                                if uid not in buySuccessInMonth4:
                                    if uid not in buySuccessInMonth5:
                                        if uid not in buySuccessInMonth6:
                                            if uid not in buySuccessInMonth7:
                                                buySuccessInMonth7.append(uid)
    print('217年7月份首次下单成功的人有%d个' % len(buySuccessInMonth7))
    
    # 算出这些人在2月份成功下单过的人数
    buySuccessInMonth1to2 = []
    buySuccessInMonth1to3 = []
    buySuccessInMonth1to4 = []
    buySuccessInMonth1to5 = []
    buySuccessInMonth1to6 = []
    buySuccessInMonth1to7 = []

    buySuccessInMonth2to3 = []
    buySuccessInMonth2to4 = []
    buySuccessInMonth2to5 = []
    buySuccessInMonth2to6 = []
    buySuccessInMonth2to7 = []

    buySuccessInMonth3to4 = []
    buySuccessInMonth3to5 = []
    buySuccessInMonth3to6 = []
    buySuccessInMonth3to7 = []

    buySuccessInMonth4to5 = []
    buySuccessInMonth4to6 = []
    buySuccessInMonth4to7 = []

    buySuccessInMonth5to6 = []
    buySuccessInMonth5to7 = []

    buySuccessInMonth6to7 = []

    for data in dataArr:
        if data.get('status') != '待付款' and data.get('status') != '订单取消':
            if data.get('date').startswith('2017-02'):
                uid = data.get('uid')
                if uid in buySuccessInMonth1:
                    if uid not in buySuccessInMonth1to2:
                        buySuccessInMonth1to2.append(uid)
            elif data.get('date').startswith('2017-03'):
                uid = data.get('uid')
                if uid in buySuccessInMonth1:
                    if uid not in buySuccessInMonth1to3:
                        buySuccessInMonth1to3.append(uid)
                if uid in buySuccessInMonth2:
                     if uid not in buySuccessInMonth2to3:
                        buySuccessInMonth2to3.append(uid)
            elif data.get('date').startswith('2017-04'):
                uid = data.get('uid')
                if uid in buySuccessInMonth1:
                    if uid not in buySuccessInMonth1to4:
                        buySuccessInMonth1to3.append(uid)
                if uid in buySuccessInMonth2:
                     if uid not in buySuccessInMonth2to4:
                        buySuccessInMonth2to4.append(uid)
                if uid in buySuccessInMonth3:
                     if uid not in buySuccessInMonth3to4:
                        buySuccessInMonth3to4.append(uid)
            elif data.get('date').startswith('2017-05'):
                uid = data.get('uid')
                if uid in buySuccessInMonth1:
                    if uid not in buySuccessInMonth1to5:
                        buySuccessInMonth1to3.append(uid)
                if uid in buySuccessInMonth2:
                     if uid not in buySuccessInMonth2to5:
                        buySuccessInMonth2to5.append(uid)
                if uid in buySuccessInMonth3:
                     if uid not in buySuccessInMonth3to5:
                        buySuccessInMonth3to5.append(uid)
                if uid in buySuccessInMonth4:
                     if uid not in buySuccessInMonth4to5:
                        buySuccessInMonth4to5.append(uid)
            elif data.get('date').startswith('2017-06'):
                uid = data.get('uid')
                if uid in buySuccessInMonth1:
                    if uid not in buySuccessInMonth1to6:
                        buySuccessInMonth1to3.append(uid)
                if uid in buySuccessInMonth2:
                     if uid not in buySuccessInMonth2to6:
                        buySuccessInMonth2to6.append(uid)
                if uid in buySuccessInMonth3:
                     if uid not in buySuccessInMonth3to6:
                        buySuccessInMonth3to6.append(uid)
                if uid in buySuccessInMonth4:
                     if uid not in buySuccessInMonth4to6:
                        buySuccessInMonth4to6.append(uid)
                if uid in buySuccessInMonth5:
                     if uid not in buySuccessInMonth5to6:
                        buySuccessInMonth5to6.append(uid)
            elif data.get('date').startswith('2017-07'):
                uid = data.get('uid')
                if uid in buySuccessInMonth1:
                    if uid not in buySuccessInMonth1to7:
                        buySuccessInMonth1to3.append(uid)
                if uid in buySuccessInMonth2:
                     if uid not in buySuccessInMonth2to7:
                        buySuccessInMonth2to7.append(uid)
                if uid in buySuccessInMonth3:
                     if uid not in buySuccessInMonth3to7:
                        buySuccessInMonth3to7.append(uid)
                if uid in buySuccessInMonth4:
                     if uid not in buySuccessInMonth4to7:
                        buySuccessInMonth4to7.append(uid)
                if uid in buySuccessInMonth5:
                     if uid not in buySuccessInMonth5to7:
                        buySuccessInMonth5to7.append(uid)
                if uid in buySuccessInMonth6:
                     if uid not in buySuccessInMonth6to7:
                        buySuccessInMonth6to7.append(uid)

    print('1月份首次下单的人在2月份又下单的有%d人' % len(buySuccessInMonth1to2))
    print('1月份首次下单的人在3月份又下单的有%d人' % len(buySuccessInMonth1to3))
    print('1月份首次下单的人在4月份又下单的有%d人' % len(buySuccessInMonth1to4))
    print('1月份首次下单的人在5月份又下单的有%d人' % len(buySuccessInMonth1to5))
    print('1月份首次下单的人在6月份又下单的有%d人' % len(buySuccessInMonth1to6))
    print('1月份首次下单的人在7月份又下单的有%d人' % len(buySuccessInMonth1to7))

    print('2月份首次下单的人在3月份又下单的有%d人' % len(buySuccessInMonth2to3))
    print('2月份首次下单的人在4月份又下单的有%d人' % len(buySuccessInMonth2to4))
    print('2月份首次下单的人在5月份又下单的有%d人' % len(buySuccessInMonth2to5))
    print('2月份首次下单的人在6月份又下单的有%d人' % len(buySuccessInMonth2to6))
    print('2月份首次下单的人在7月份又下单的有%d人' % len(buySuccessInMonth2to7))

    print('3月份首次下单的人在4月份又下单的有%d人' % len(buySuccessInMonth3to4))
    print('3月份首次下单的人在5月份又下单的有%d人' % len(buySuccessInMonth3to5))
    print('3月份首次下单的人在6月份又下单的有%d人' % len(buySuccessInMonth3to6))
    print('3月份首次下单的人在7月份又下单的有%d人' % len(buySuccessInMonth3to7))

    print('4月份首次下单的人在5月份又下单的有%d人' % len(buySuccessInMonth4to5))
    print('4月份首次下单的人在6月份又下单的有%d人' % len(buySuccessInMonth4to6))
    print('4月份首次下单的人在7月份又下单的有%d人' % len(buySuccessInMonth4to7))

    print('5月份首次下单的人在6月份又下单的有%d人' % len(buySuccessInMonth5to6))
    print('5月份首次下单的人在7月份又下单的有%d人' % len(buySuccessInMonth5to7))

    print('6月份首次下单的人在7月份又下单的有%d人' % len(buySuccessInMonth6to7))

    # 导出csv
    csv = ' ,2,3,4,5,6,7'
    csv += '\n1,%d,%d,%d,%d,%d,%d' % (len(buySuccessInMonth1to2), len(buySuccessInMonth1to3), len(buySuccessInMonth1to4), len(buySuccessInMonth1to5), len(buySuccessInMonth1to6), len(buySuccessInMonth1to7))
    csv += '\n2, ,%d,%d,%d,%d,%d' % (len(buySuccessInMonth2to3), len(buySuccessInMonth2to4), len(buySuccessInMonth2to5), len(buySuccessInMonth2to6), len(buySuccessInMonth2to7))
    csv += '\n3, , ,%d,%d,%d,%d' % (len(buySuccessInMonth3to4), len(buySuccessInMonth3to5), len(buySuccessInMonth3to6), len(buySuccessInMonth3to7))
    csv += '\n4, , , ,%d,%d,%d' % (len(buySuccessInMonth4to5), len(buySuccessInMonth4to6), len(buySuccessInMonth4to7))
    csv += '\n5, , , , ,%d,%d' % (len(buySuccessInMonth5to6), len(buySuccessInMonth5to7))
    csv += '\n6, , , , , ,%d' % (len(buySuccessInMonth6to7))
    helper.writeFile(csv, 'analysis.csv')
    print('保存成功')

    buyAgain130 = []
    buyAgain160 = []
    buyAgain190 = []
    for uid in buySuccessInMonth1:
        for data in dataArr:
            if data.get('uid') == uid:
                if data.get('status') != '待付款' and data.get('status') != '订单取消':
                    if data.get('date').startswith('2017-02'):
                        if data.get('uid') not in buyAgain130:
                            buyAgain130.append(data.get('uid'))
                    if data.get('date').startswith('2017-02') or data.get('date').startswith('2017-03'):
                         if data.get('uid') not in buyAgain160:
                            buyAgain160.append(data.get('uid'))
                    if data.get('date').startswith('2017-02') or data.get('date').startswith('2017-03') or data.get('date').startswith('2017-04'):
                         if data.get('uid') not in buyAgain190:
                            buyAgain190.append(data.get('uid'))
    buyAgain230 = []
    buyAgain260 = []
    buyAgain290 = []
    for uid in buySuccessInMonth2:
        for data in dataArr:
            if data.get('uid') == uid:
                if data.get('status') != '待付款' and data.get('status') != '订单取消':
                    if data.get('date').startswith('2017-03'):
                        if data.get('uid') not in buyAgain230:
                            buyAgain230.append(data.get('uid'))
                    if data.get('date').startswith('2017-03') or data.get('date').startswith('2017-04'):
                         if data.get('uid') not in buyAgain260:
                            buyAgain260.append(data.get('uid'))
                    if data.get('date').startswith('2017-03') or data.get('date').startswith('2017-04') or data.get('date').startswith('2017-05'):
                         if data.get('uid') not in buyAgain290:
                            buyAgain290.append(data.get('uid'))
    buyAgain330 = []
    buyAgain360 = []
    buyAgain390 = []
    for uid in buySuccessInMonth3:
        for data in dataArr:
            if data.get('uid') == uid:
                if data.get('status') != '待付款' and data.get('status') != '订单取消':
                    if data.get('date').startswith('2017-04'):
                        if data.get('uid') not in buyAgain330:
                            buyAgain330.append(data.get('uid'))
                    if data.get('date').startswith('2017-04') or data.get('date').startswith('2017-05'):
                         if data.get('uid') not in buyAgain360:
                            buyAgain360.append(data.get('uid'))
                    if data.get('date').startswith('2017-04') or data.get('date').startswith('2017-05') or data.get('date').startswith('2017-06'):
                         if data.get('uid') not in buyAgain390:
                            buyAgain390.append(data.get('uid'))
    buyAgain430 = []
    buyAgain460 = []
    buyAgain490 = []
    for uid in buySuccessInMonth4:
        for data in dataArr:
            if data.get('uid') == uid:
                if data.get('status') != '待付款' and data.get('status') != '订单取消':
                    if data.get('date').startswith('2017-05'):
                        if data.get('uid') not in buyAgain430:
                            buyAgain430.append(data.get('uid'))
                    if data.get('date').startswith('2017-05') or data.get('date').startswith('2017-06'):
                         if data.get('uid') not in buyAgain460:
                            buyAgain460.append(data.get('uid'))
                    if data.get('date').startswith('2017-05') or data.get('date').startswith('2017-06') or data.get('date').startswith('2017-07'):
                         if data.get('uid') not in buyAgain490:
                            buyAgain490.append(data.get('uid'))
    buyAgain530 = []
    buyAgain560 = []
    for uid in buySuccessInMonth5:
        for data in dataArr:
            if data.get('uid') == uid:
                if data.get('status') != '待付款' and data.get('status') != '订单取消':
                    if data.get('date').startswith('2017-06'):
                        if data.get('uid') not in buyAgain530:
                            buyAgain530.append(data.get('uid'))
                    if data.get('date').startswith('2017-06') or data.get('date').startswith('2017-07'):
                         if data.get('uid') not in buyAgain560:
                            buyAgain560.append(data.get('uid'))
    buyAgain630 = []
    for uid in buySuccessInMonth6:
        for data in dataArr:
            if data.get('uid') == uid:
                if data.get('status') != '待付款' and data.get('status') != '订单取消':
                    if data.get('date').startswith('2017-07'):
                        if data.get('uid') not in buyAgain630:
                            buyAgain630.append(data.get('uid'))
    print('1月份首次下单的用户30天复购人数为%d,60天复购人数为%d,90天复购人数为%d' % (len(buyAgain130), len(buyAgain160), len(buyAgain190)))
    print('2月份首次下单的用户30天复购人数为%d,60天复购人数为%d,90天复购人数为%d' % (len(buyAgain230), len(buyAgain260), len(buyAgain290)))
    print('3月份首次下单的用户30天复购人数为%d,60天复购人数为%d,90天复购人数为%d' % (len(buyAgain330), len(buyAgain360), len(buyAgain390)))
    print('4月份首次下单的用户30天复购人数为%d,60天复购人数为%d,90天复购人数为%d' % (len(buyAgain430), len(buyAgain460), len(buyAgain490)))
    print('5月份首次下单的用户30天复购人数为%d,60天复购人数为%d' % (len(buyAgain530), len(buyAgain560)))
    print('6月份首次下单的用户30天复购人数为%d' % (len(buyAgain630)))

if __name__ == '__main__':
    main()