#!/usr/bin/env python
# -*- coding: utf-8 -*-

import helper
import math, os, json
from order import Order

cookies = {
    'hcsf': 'd4qjrg3lmnh59c5r3b6s376v93',
    'd4qjrg3lmnh59c5r3b6s376v93': '1g096uFBsSxokP1hAAKh0zfvbN3GEtMHW0lbhNvm9adxSQ2Pchef0RIpB7xfOaRHVBtu1KDo5KTNVKhUW4DfqUjhnlajdAwRlysfczzSeFs9Yc7adgCgdwWYqZXP14flj0B9Y5WMG%2BeFy7NlapnmRf93NamGgVq8eRdk8ZqM0WSBPDXCOr7MiFWGuj2p4%2B5x64RDrn9LiK2uKboKduRMoUnNAHaIqxXjftL0cz%2B4K6INCcEaidEO9sdMy0hRgDmpix1DbjqMvhjhrwy42vThais6Cih%2F4eMWWRcuweK4OU5vUKasLe6wQLJHIuy5zzok8Ej1HvtO4i8Cu55o4OE3xhT3A66Fa8bMavhU8ftFZ8Ad2CMlamxhRfSHjIWIO4tnJ9p3KYEdAlbtosPBlkvAih6RXMIPyH1OkFad3dzhR0dOaZ3AirKtIrGE6dgp3ZhM%2Flt%2F6znuGNbZrzKky9QZaW4gbCwef0%2Bhgx5Qli82LfM3IVcDofC65Obr2liXpG96P686O2m8PQ%3D%3D'
}

orderArr = []

def hasOrder(orderid):
    global orderArr
    for o in orderArr:
        if o.orderid == orderid:
            return True
    return False

def main():
    global orderArr
    # 先读取本地数据
    if(os.path.exists('data.json')):
        jsonStr = helper.readFile('data.json')
        dataArr = json.loads(jsonStr)
        for data in dataArr:
            orderArr.append(Order(data.get('orderid'), data.get('uName'), data.get('uid'), data.get('money'), data.get('freight'), data.get('status'), data.get('date'), data.get('channel')))

    global cookies
    page = 128
    maxPage = 99999
    while True:
        page += 1
        if page > maxPage:
            break
        pq = helper.get('https://backend.kaluli.com/tradeadmin.php/kaluli_order/index?p=%d' % page, cookies, sleep = 3)
        href = pq('#page > a')[-1].get('href')
        if href:
            maxPage = int(href.split('=')[1])
        spanArr = pq('td > span')
        tdArr = pq('tr > td')
        for i in range(0, len(tdArr), 10):
            # 0=> <td align="center">1708068631818732</td>
            # 1=> <td align="center"  class="J_tips"  data-simpletooltip-theme="white"  title="虎扑uid：29115191"   >曹银</td>
            # 2=> <td align="center">曹银</td>
            # 3=> <td align="center">433.05</td>
            # 4=> <td align="center">￥25.50元</td>
            # 5=> <td align="center"><span class="c-blue">待付款</span></td>
            
            # 6=> <td align="center">￥0.00元</td>
            # 7=> <td align="center" class="J_tips" data-simpletooltip-theme="white"  title="付款时间：- <br />创建时间：2017-08-06 10:25:18 <br />最后更新：2017-08-06 10:25:18"        >2017-08-06 10:25:18</td>
            # 8=> <td align="center">m站</td><!--来源渠道 -->
            # 9=> <td align="center">
            #      <a href="/tradeadmin.php/kaluli_order/orderDetail/orderNumber/1708068631818732" >详情</a>
            # </td>
            orderid = tdArr[i].text
            if not hasOrder(orderid):
                uName = tdArr[i + 1].text
                uid = tdArr[i + 1].get('title').split('：')[1]
                if uid == '30002508':
                    uName = '有问题的名字'
                money = tdArr[i + 3].text
                freight = tdArr[i + 4].text
                status = spanArr[math.floor(i / 10)].text
                date = tdArr[i + 7].text
                channel = tdArr[i + 8].text
                o = Order(orderid, uName, uid, money, freight, status, date, channel)
                orderArr.append(o)
            else:
                break
        # 爬完一页，就将数据写到本地
        jsonStr = '['
        for o in orderArr:
            jsonStr += '\n\t' + o.toJson() if jsonStr == '[' else ',\n\t' + o.toJson()
        jsonStr += '\n]'
        helper.writeFile(jsonStr, 'data.json')
        # break

if __name__ == '__main__':
    main()