#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 扒取子订单的数据

import helper
import math, os, json, re
from order import SubOrder

cookies = {
	'hcsf': 'd4qjrg3lmnh59c5r3b6s376v93',
	'd4qjrg3lmnh59c5r3b6s376v93': '1g096uFBsSxokP1hAAKh0zfvbN3GEtMHW0lbhNvm9adxSQ2Pchef0RIpB7xfOaRHVBtu1KDo5KTNVKhUW4DfqUjhnlajdAwRlysfczzSeFs9Yc7adgCgdwWYqZXP14flj0B9Y5WMG%2BeFy7NlapnmRf93NamGgVq8eRdk8ZqM0WSBPDXCOr7MiFWGuj2p4%2B5x64RDrn9LiK2uKboKduRMoUnNAHaIqxXjftL0cz%2B4K6INCcEaidEO9sdMy0hRgDmpix1DbjqMvhjhrwy42vThais6Cih%2F4eMWWRcuweK4OU5vUKasLe6wQLJHIuy5zzok8Ej1HvtO4i8Cu55o4OE3xhT3A66Fa8bMavhU8ftFZ8Ad2CMlamxhRfSHjIWIO4tnJ9p3KYEdAlbtosPBlkvAih6RXMIPyH1OkFad3dzhR0dOaZ3AirKtIrGE6dgp3ZhM%2Flt%2F6znuGNbZrzKky9QZaW4gbCwef0%2Bhgx5Qli82LfM3IVcDofC65Obr2liXpG96P686O2m8PQ%3D%3D'
}

orderArr = []

def hasOrder(id):
	global orderArr
	for o in orderArr:
		if o.orderid == id:
			return True
	return False

if __name__ == '__main__':
	# # 先读取本地数据
	# if(os.path.exists('subOrder.json')):
	# 	jsonStr = helper.readFile('subOrder.json')
	# 	dataArr = json.loads(jsonStr)
	# 	for data in dataArr:
	# 		orderArr.append(SubOrder(data.get('orderid'), data.get('kuaiDiId'), data.get('goodTitle'), data.get('uid'), data.get('count'), data.get('payMoney'), data.get('orderStatus'), data.get('payStatus'), data.get('orderTimer'), data.get('channel'), data.get('barCodr'), data.get('warehouse')))
	# page = 185
	# while True:
	# 	page += 1
	# 	pq = helper.get('https://backend.kaluli.com/tradeadmin.php/kaluli_order/index_old?p=%d' % page, cookies, sleep=1)
	# 	spanArr = pq('td > span')

	# 	tdArr = pq('tr > td')
	# 	# orderid, kuaiDiId, goodTitle, uid, count, payMoney,
	# 	# orderStatus, payStatus, orderTimer, channel, barCodr, warehouse
	# 	# print(tdArr[15].get('title'))
	# 	# break
	# 	for i in range(0, len(tdArr), 14):
	# 		orderid = tdArr[i + 1].text
	# 		if hasOrder(orderid):
	# 			continue
	# 		# <br />快递单号： 535955165891                        <br />
	# 		kuaiDiId = '-'
	# 		title = tdArr[i + 1].get('title')
	# 		pattern = re.compile(r'快递单号： [\d\-]*')
	# 		match = pattern.findall(title)
	# 		if match and len(match) == 1:
	# 			kuaiDiId = match[0].replace('快递单号： ', '')
	# 		goodTitle = tdArr[i + 2].get('title')
	# 		uid = tdArr[i + 3].get('title').replace('虎扑uid：', '')
	# 		count = tdArr[i + 6].text
	# 		payMoney = tdArr[i + 7].text.replace('￥', '').replace('元', '')
	# 		orderStatus = spanArr[math.floor(i / 14) * 2].text #tdArr[i + 9].text
	# 		payStatus = spanArr[math.floor(i / 14) * 2 + 1].text #tdArr[i + 10].text
	# 		orderTimer = tdArr[i + 11].text
	# 		channel = tdArr[i + 12].text
	# 		pq = helper.get('https://backend.kaluli.com/tradeadmin.php/kaluli_order/orderDetail/orderNumber/%s' % orderid, cookies, sleep=1)
	# 		tdArr1 = pq('tr > td')
	# 		barCodr = tdArr1[3].text
	# 		warehouse = tdArr1[10].text
	# 		subOrder = SubOrder(orderid, kuaiDiId, goodTitle, uid, count, payMoney, orderStatus, payStatus, orderTimer, channel, barCodr, warehouse)
	# 		orderArr.append(subOrder)
	# 	jsonStr = '['
	# 	for o in orderArr:
	# 		jsonStr += '\n\t' + o.toJson() if jsonStr == '[' else ',\n\t' + o.toJson()
	# 	jsonStr += '\n]'
	# 	helper.writeFile(jsonStr, 'subOrder.json')
	# 	if page > 280:
	# 		break
	
	txt = helper.readFile('subOrder.json')
	subOrderJsonArr = json.loads(txt)
	subOrderJsonArr = [order for order in subOrderJsonArr if order.get('warehouse') == '香港直邮' and order.get('payStatus') != '待付款']
	# # print(len(subOrderJsonArr))
	for data in subOrderJsonArr:
		orderArr.append(SubOrder(data.get('orderid'), data.get('kuaiDiId'), data.get('goodTitle'), data.get('uid'), data.get('count'), data.get('payMoney'), data.get('orderStatus'), data.get('payStatus'), data.get('orderTimer'), data.get('channel'), data.get('barCodr'), data.get('warehouse')))

	# # 6月15到7月15之间下过单的用户
	# uidArr = [order.uid for order in orderArr if order.orderMonth < 7 or (order.orderMonth == 7 and order.orderDate <= 15)]
	# # print(len(uidArr))
	# uidArr = list(set(uidArr))
	# # print(len(uidArr))
	# # 7月15号到8月15号下过单的用户
	# uidArr1 = [order.uid for order in orderArr if (order.orderMonth == 7 and order.orderDate > 15) or (order.orderMonth == 8 and order.orderDate <= 15)]
	# uidArr1 = list(set(uidArr1))

	# # 6月15到7月15之间下过单的用户又在7月15号到8月15号之间下过单的数量
	# uidArr2 = []
	# for uid in uidArr:
	# 	if uid in uidArr1:
	# 		uidArr2.append(uid)
	# print(len(uidArr2))


	# orderArrInMonth6 = [order for order in orderArr if order.orderMonth < 7 or (order.orderMonth == 7 and order.orderDate <= 15)]
	csv = 'orderid,kuaiDiId,goodTitle,uid,count,payMoney,orderStatus,payStatus,orderTimer,channel,barCodr,warehouse\n'
	for order in orderArr:
	# for order in orderArrInMonth6:
		csv += order.toCSV() + '\n'
	helper.writeFile(csv, 'order.csv')

	# orderArrInMonth6 = [order for order in orderArr if order.uid in uidArr2 and ((order.orderMonth == 8 and order.orderMonth <= 15) or (order.orderMonth == 7 and order.orderDate > 15))]
	# csv = 'orderid,kuaiDiId,goodTitle,uid,count,payMoney,orderStatus,payStatus,orderTimer,channel,barCodr,warehouse\n'
	# for order in orderArrInMonth6:
	# 	csv += order.toCSV() + '\n'
	# helper.writeFile(csv, 'month7-8.csv')
	


	# 打印所有的仓库
	# warehouseArr = []
	# for o in subOrderJsonArr:
	# 	if o.get('warehouse') not in warehouseArr:
	# 		warehouseArr.append(o.get('warehouse'))
	# print(warehouseArr)




	# tt = []
	# tt1 = []
	# for order in subOrderJsonArr:
	# 	payStatus = order.get('payStatus')
	# 	orderStatus = order.get('orderStatus')
	# 	if payStatus not in tt:
	# 		tt.append(payStatus)
	# 	if orderStatus not in tt1:
	# 		tt1.append(orderStatus)
	# print(tt)
	# print(tt1)
	# print(len(subOrderJsonArr))