#!/usr/bin/env python
# -*- coding: utf-8 -*-

class Order(object):

        #  <th class="tCenter">订单编号</th>
        #     <th class="tCenter">下单人</th>
        #     <th class="tCenter">收货人姓名</th>
        #     <th class="tCenter">支付金额</th>
        #     <th class="tCenter">运费</th>
        #     <th class="tCenter">订单状态</th>
            
        #     <th class="tCenter">税费</th>
        #     <th class="tCenter">下单时间</th>
        #     <th class="tCenter">来源渠道</th>
        #     <th class="tCenter">操作</th>
    def __init__(self, orderid, uName, uid, money, freight, status, date, channel):
        super(Order, self).__init__()
        self.orderid = orderid
        self.uName = uName
        self.uid = uid
        self.money = money
        self.freight = freight
        self.status = status
        self.date = date
        self.channel = channel
    
    def toJson(self):
        return '{"orderid":"%s","uid":"%s","money":"%s","freight":"%s","status":"%s","date":"%s","channel":"%s"}' % (self.orderid, self.uid, self.money, self.freight, self.status, self.date, self.channel)


class SubOrder(object):
    """docstring for SubOrder"""
    def __init__(self, orderid, kuaiDiId, goodTitle, uid, count, payMoney, orderStatus, payStatus, orderTimer, channel, barCodr, warehouse):
        super(SubOrder, self).__init__()
        self.orderid = orderid
        self.kuaiDiId = kuaiDiId
        self.goodTitle = goodTitle
        self.uid = uid
        self.count = count
        self.payMoney = payMoney
        self.orderStatus = orderStatus
        self.payStatus = payStatus
        self.orderTimer = orderTimer
        self.channel = channel
        self.barCodr = barCodr
        self.warehouse = warehouse

        a = orderTimer.split(' ')[0].split('-')
        self.orderYear = int(a[0])
        self.orderMonth = int(a[1])
        self.orderDate = int(a[2])

    def isDateLessThan(self, year, month, date):
        if self.orderYear < year:
            return True
        if self.orderYear == year:
            if self.orderMonth < month:
                return True
            if self.orderMonth == month:
                return self.orderDate <= date
        return False

    def isDateGreatThan(self, year, month, date):
        return not self.isDateLessThan(year, month, date)
            

    def toJson(self):
        return '{"orderid":"%s","kuaiDiId":"%s","goodTitle":"%s","uid":"%s","count":"%s","payMoney":"%s","orderStatus":"%s","payStatus":"%s","orderTimer":"%s","channel":"%s","barCode":"%s","warehouse":"%s"}' % (self.orderid, self.kuaiDiId, self.goodTitle, self.uid, self.count, self.payMoney, self.orderStatus, self.payStatus, self.orderTimer, self.channel, self.barCodr, self.warehouse)

    def toCSV(self):
        return '"%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s"' % (self.orderid, self.kuaiDiId, self.goodTitle, self.uid, self.count, self.payMoney, self.orderStatus, self.payStatus, self.orderTimer, self.channel, self.barCodr, self.warehouse)
        