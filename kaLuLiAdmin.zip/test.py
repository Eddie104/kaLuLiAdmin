import helper, json
from order import SubOrder

if __name__ == '__main__':
	# for page in range(1, 6):
	# 	pq = helper.get('https://www.kaluli.com/product?page=%d' % page)
	# 	aArr = pq('li > a.clearfix')
	# 	for a in aArr:
	# 		# print(a.get('href'))
	# 		# /product/630.html#qk=detail&page=1&order=6
	# 		id = a.get('href').split('.')[0].split('/')[-1]
	# 		# print(id)
	# 		print('https://track.kaluli.com/tradelink?union_id=shihuojs&to=https%3A%2F%2Fwww.kaluli.com%2Fproduct%2F' + id + '.html')
	# 		# break
	# 	# break
	



	# helper.json2csv('subOrder')
	

	uidText = helper.readFile('beijingUID.txt')
	uidArr = uidText.split('\n')


	jsonText = helper.readFile('subOrder.json')
	orderJsonArr = json.loads(jsonText)
	orderArr = [SubOrder(orderJson.get("orderid"), orderJson.get("kuaiDiId"), orderJson.get("goodTitle"), orderJson.get("uid"), orderJson.get("count"), orderJson.get("payMoney"), orderJson.get("orderStatus"), orderJson.get("payStatus"), orderJson.get("orderTimer"), orderJson.get("channel"), orderJson.get("barCodr"), orderJson.get("warehouse")) for orderJson in orderJsonArr]

	# 找出6月27号到6月30号之间下过单的订单数据
	orderInJune = [order for order in orderArr if order.isDateLessThan(2017, 6, 30) and order.isDateGreatThan(2017, 6, 26) and order.uid in uidArr]
	# 找出6月27号到6月30号之间下过单的用户ID
	uidInJune = [order.uid for order in orderInJune]
	# print(len(uidInJune))
	
	# 找出这些人在7月1号到7月31号之间下过单的订单数据
	orderInJuly = [order for order in orderArr if order.isDateLessThan(2017, 7, 31) and order.isDateGreatThan(2017, 7, 0) and order.uid in uidInJune]
	# 找出这些人在7月1号到8月15号之间下过单的订单数据
	orderInJuly1 = [order for order in orderArr if order.isDateLessThan(2017, 8, 15) and order.isDateGreatThan(2017, 7, 0) and order.uid in uidInJune]

	csvJuly = 'orderid, kuaiDiId, goodTitle, uid, count, payMoney, orderStatus, payStatus, orderTimer, channel, barCodr, warehouse\n'
	for order in orderInJuly:
		csvJuly += order.toCSV() + '\n'
	helper.writeFile(csvJuly, 'csvJuly.csv')